<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Message extends CI_Controller {
	
	public function index()
	{
		if(isset($_SESSION['newsession']) == TRUE) 
		{
		$this->load->view('Post');
		}
		else
		{
			$this->load->helper('url');
			redirect(base_url()."index.php/user/login/");
		}			
		
	}
	
	public function doPost()
	{
		if(isset($_SESSION['newsession']) == TRUE) 
		{
			$this->load->model('MsgMod');
		
		
			$input = $this->input->post('newMessage');
		
			$name = $_SESSION["newsession"];
		
			$data = $this->MsgMod->insertMessage($name, $input);
			
			$this->load->helper('url');
			
			redirect(base_url()."index.php/user/view/".$name);
		} 
		else 
		{
			$this->load->helper('url');
			redirect(base_url()."index.php/user/login/");
		}
		
		
	}	
	
	
}
?>