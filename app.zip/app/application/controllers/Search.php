<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

	public function index()
	{
		$this->load->model('MsgMod');
		
		$data = $this->MsgMod->getSearch($input = "");
		
		$viewData = array("results" => $data);
		
		$this->load->view('search', $viewData);
		
	}
	

	public function doSearch($input = null)
	{
		$this->load->model('MsgMod');
		
		$input = $this->input->get('keywords');
		
		if($input==null){
			echo "Search not specified"; return; 
		}
		
		$data = $this->MsgMod->getSearch($input);
		
		$viewData = array("results" => $data);
		
		$this->load->view('search', $viewData);
	}
	
}
?>