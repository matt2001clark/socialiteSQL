<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	
	// *******************************
	// * 		  VIEW CODE 		 *
	// *******************************
	public function view($user_username = null)
	{
		// $this->load->model('MsgMod');
		$this->load->model('UserMod');
		if($user_username==null)
		{
			echo "Username not specified"; return; 
		}
		
		$name = $_SESSION["newsession"];
		
		// if($this->UserMod->isFollowing($name, $user_username))
		// {
		// 	$data = $this->MsgMod->getMessages($user_username);
		
		// 	$viewData = array("results" => $data);
			
		// 	$_SESSION["newsession3"]=($user_username);
		
		// 	$this->load->view('msg_message', $viewData);
		// }
		// else if ($name == $user_username)
		if ($name == $user_username)
		{
			//$data = $this->MsgMod->getMessages($user_username);
		
			//$viewData = array("results" => $data);
		
			//$this->load->view('discover', $viewData);
			
			/* ORIGINAL CODE HERE */
			//$this->load->view('discover');

			// TESTING
			
			$this->load->model('UserMod');
			$data = $this->UserMod->randEvent();
		
			$viewData = array("results" => $data);
		
			$this->load->view('discoverHeader');
			$this->load->view('discoverContent', $viewData);
			$this->load->view('navBarDiscover');
		}
		// else
		// {
		// 	$data = $this->MsgMod->getMessages($user_username);
		
		// 	$viewData = array("results" => $data);
			
		// 	$_SESSION["newsession4"]=($user_username);
		
		// 	$this->load->view('msg_message - follow', $viewData);
		// }
		
	}
	
	// *******************************
	// * 	LOGIN & LOGOUT CODE		 *
	// *******************************

	// Loads login page on first entry
	public function login()
	{
		$this->load->view('loginHeader');
		$this->load->view('loginContent');
		$this->load->view('loginFooter');
	}

	// Check if username and password is valid
	public function doLogin($username = null, $password = null)
	{
		$this->load->model('UserMod');
		
		if($username==null || $password==null || ($username==null && $password==null))
		{
			$this->login(); 
		}
		
		$username = $this->input->post('username');
		$password = sha1($this->input->post('password'));
		
		$this->load->model('UserMod');
		
		if($this->UserMod->checkLogin($username,$password))
		{
			$_SESSION["newsession"]=($username);
			
			$this->load->helper('url');
			
			redirect(base_url()."index.php/user/view/".$username);
						
		}
		else 
		{
			$this->load->helper('url');
			base_url('index.php/user/doLogin/');
			echo "<p style='color:red;'>" . "Invalid Username and/or Password" . "</p>";
		}
		
	}
	
	// Redirect user to login page and destroy current session
	public function logout()
	{
		$this->session->sess_destroy();
		$this->load->view('loginHeader');
		$this->load->view('loginContent');
		$this->load->view('loginFooter');
				
	}
	
	public function signUp()
	{
		$this->load->view('guestHeader');
		$this->load->view('signup');
		$this->load->view('signupFooter');
				
	}
	
	public function insertMember($Firstname = null, $Surname = null, $Username = null, $Password = null, $Bio = null, $School = null, $RepStatus = null)
	{
		$this->load->model('UserMod');
		
		if($Username==null || $Password==null || ($Username==null && $Password==null))
		{
			$this->signUp(); 
			echo "<p style='color:red;'>" . "Missing credentials" . "</p>";
		}
		
		$Firstname = $this->input->post('Firstname');
		$Surname = $this->input->post('Surname');
		$Username = $this->input->post('Username');
		$Password = sha1($this->input->post('password'));
		$Bio = $this->input->post('Bio');
		$School = $this->input->post('School');
		$RepStatus = $this->input->post('RepStatus');
		
		$this->load->model('UserMod');

		if($this->UserMod->insertMember($Firstname, $Surname, $Username, $Password, $Bio, $School, $RepStatus))
		{
			$this->load->view('loginHeader');
			$this->load->view('loginContent');
			$this->load->view('loginFooter');	
		}
		else{
			echo "<br/>"."<p style='color:red;'>" . "Missing credentials, or Username already taken" . "</p>";
		}
		
		
	}

	// *******************************
	// * 		PROFILE CODE		 *
	// *******************************
	
	public function profile($username)
	{
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profileHeader($username);
		
		$data2 = $this->UserMod->countEvent($username);
		
		$data3 = $this->UserMod->countPost($username);
		
		
		//$viewData = array("results" => $data);
		
		$viewData['results'] = $data;
		$viewData['results2'] = $data2;
		$viewData['results3'] = $data3;
		
		$this->load->view('profileHeader', $viewData);
		
		
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profilePost($username);
		
		$viewData = array("results" => $data);
		
		if ($data == null) {
			
		$this->load->view('profileNoPosts');
		$this->load->view('navBarProfile');
		
		}
		else{
			
			$this->load->view('profilePosts', $viewData);
			$this->load->view('navBarProfile');
			
		}
	}

	// Load users Posts on Posts button click
	public function userPosts($username)
	{
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profileHeader($username);
		
		$data2 = $this->UserMod->countEvent($username);
		
		$data3 = $this->UserMod->countPost($username);
		
		
		$viewData['results'] = $data;
		$viewData['results2'] = $data2;
		$viewData['results3'] = $data3;
		
		$this->load->view('profileHeader', $viewData);
		
		$this->load->model('UserMod');
		$data = $this->UserMod->profilePost($username);
		$viewData = array("results" => $data);
		
		if ($data == null) {
			
		$this->load->view('profileNoPosts');
		$this->load->view('navBarProfile');
		
		}
		else{
			
			$this->load->view('profilePosts', $viewData);
			$this->load->view('navBarProfile');
			
		}
	}

	// Load users Events on Posts button click
	public function userEvents($username)
	{
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profileHeader($username);
		
		$data2 = $this->UserMod->countEvent($username);
		
		$data3 = $this->UserMod->countPost($username);
		
		
		//$viewData = array("results" => $data);
		
		$viewData['results'] = $data;
		$viewData['results2'] = $data2;
		$viewData['results3'] = $data3;
		
		$this->load->view('profileHeader', $viewData);
		
		$this->load->model('UserMod');
		$data = $this->UserMod->profileEvent($username);
		$viewData = array("results" => $data);
		
		if ($data == null) {
			
		$this->load->view('profileNoEvents');
		$this->load->view('navBarProfile');
		
		}
		else{
			
			$this->load->view('profileEvents', $viewData);
			$this->load->view('navBarProfile');
			
		}
	}

	// Loads the Profile Post Counter
	public function countPost($username)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->profileHeader($username);
		$viewData = array("results" => $data);

		$this->load->view('profileHeader',$viewData);
		$this->load->view('profilePosts');
		$this->load->view('navBarProfile');
	}
	
	// Loads the Profile Event Counter
	public function countEvent($username)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->profileHeader($username);
		$viewData = array("results" => $data);

		$this->load->view('profileHeader', $viewData);
		$this->load->view('profilePosts');
		$this->load->view('navBarProfile');
	}


	// *******************************
	// * 		CREATE CODE		     *
	// *******************************

	public function create()
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->createPopulate();
		
		$viewData = array("results" => $data);

		$this->load->view('createHeader');
		$this->load->view('createPost', $viewData);
		$this->load->view('navBarCreate');
	}

	// On Create [Post] button click load 
	public function addPost($postContent = null, $postEvent = null)
	{
		$this->load->model('UserMod');

		if($postContent==null || $postEvent==null || ($postContent==null && $postEvent==null))
		{
			$this->create();
		}
		
		$postContent = $this->input->post('postContent');
		$postEvent = $this->input->post('postEvent');
		$name = $_SESSION["newsession"];

		$this->load->model('UserMod');

		if($this->UserMod->insertPost($postContent, $postEvent, $name))
		{
			$this->create();
		}
	}

	// On Create Event button click load relevant page 
	public function createEvent()
	{
		$name = $_SESSION["newsession"];
		$this->load->model('UserMod');

		if($this->UserMod->checkStatus($name))
		{
			$data = $this->UserMod->createVenuePopulate();
			$data2 = $this->UserMod->createEventPopulate();

			$viewData['results'] = $data;
			$viewData['results2'] = $data2;

			$this->load->view('createHeader');
			$this->load->view('createEvent', $viewData);
			$this->load->view('navBarCreate');	
		}
		else 
		{
			$this->load->view('createHeader');
			$this->load->view('createError');
			$this->load->view('navBarCreate');
		}
	}
	
	// On Create Event [add] button click load 
	public function addEvent($eventName = null, $eventDetail = null, $eventVenue = null, $eventDate = null, $eventSociety = null)
	{
		$this->load->model('UserMod');

		if($eventName = null || $eventDetail = null || $eventVenue = null || $eventDate = null || $eventSociety = null)
		{
			$this->createEvent();
		}
		
		$eventName = $this->input->post('eventName');
		$eventDetail = $this->input->post('eventDetail');
		$eventVenue = $this->input->post('eventVenue');
		$eventDate = $this->input->post('eventDate');
		$eventSociety = $this->input->post('eventSociety');
		// $name = $_SESSION["newsession"];

		$this->load->model('UserMod');

		if($this->UserMod->insertEvent($eventName, $eventDetail, $eventVenue, $eventDate, $eventSociety))
		{
			$this->createEvent();
		}
		else{
			$this->createEvent(); //reloads page but doesnt add event
		}
	}

	// public function submitPost(){
	// 	if(isset($_SESSION['newsession']) == TRUE) 
	// 	{
	// 		$this->load->model('UserMod');
		
	// 		$input = $this->input->post('post_content');
		
	// 		$name = $_SESSION["newsession"];
		
	// 		$data = $this->MsgMod->insertMessage($name, $input);
			
	// 		$this->load->helper('url');
			
	// 		redirect(base_url()."index.php/user/view/".$name);
	// 	} 
	// 	else 
	// 	{
	// 		$this->load->helper('url');
	// 		redirect(base_url()."index.php/user/login/");
	// 	}
	// }

	// *******************************
	// * 		DISCOVER CODE		 *
	// *******************************
	
	// Load discover page on navigation bar
	public function discover()
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->randEvent();
		
		$viewData = array("results" => $data);
		
		$this->load->view('discoverHeader');
		$this->load->view('discoverContent', $viewData);
		$this->load->view('navBarDiscover');
	}

	// Display results of search query on search Content page
	public function results($text = null)
	{
		$text = $this->input->post('text');
		
		$this->load->model('UserMod');
		$data = $this->UserMod->searchText($text);
		
		$viewData = array("results" => $data);
		
		$this->load->view('discoverHeader');
		$this->load->view('discoverSearch', $viewData);
		$this->load->view('navBarDiscover');		
	}

	// I DONT KNOW HOW RELEVANT THE NEXT FUNCTIONS ARE BUT STILL
	// USEFUL TO ADAPT THEM FOR THE NEW DISCOVER PAGE 
	// ESPECIALLY WHEN SEARCH RESULTS MIGHT BE NULL ETC 

	public function searchDates()
	{
		$this->load->view('searchDates');
	}
	
		public function searchCategory()
	{
		$this->load->view('searchCategory');
	}

	public function setDate($searchDate = null)
	{
		$this->load->view('searchDates');
		$date = $this->input->post('searchDate');
				
		echo "Date= " . $date;
	}
	
		public function setCategory($sports = null, $music = null, $movie = null, $other = null)
	{
		$this->load->view('searchCategory');
		$sports = $this->input->post('sports');
		$music = $this->input->post('music');
		$movie = $this->input->post('movie');
		$other = $this->input->post('other');
		
		echo "Sports= " . $sports . ", Music= " . $music . ", Movie= " . $movie . ", Other= " . $other;
	}

	// Load all Events on Posts button click
	public function allEvents()
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->discoverEvents();
		
		$viewData = array("results" => $data);
		
		$this->load->view('discoverHeader');
		$this->load->view('discoverEvents', $viewData);
		$this->load->view('navBarDiscover');
	}

	// Load all Societies on Posts button click
	public function allSocieties()
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->discoverSocieties();
		
		$viewData = array("results" => $data);
		
		$this->load->view('discoverHeader');
		$this->load->view('discoverSocieties', $viewData);
		$this->load->view('navBarDiscover');
	}

	// Load all People on Posts button click
	public function allPeople()
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->discoverPeople();
		
		$viewData = array("results" => $data);
		
		$this->load->view('discoverHeader');
		$this->load->view('discoverPeople', $viewData);
		$this->load->view('navBarDiscover');
	}


	// *******************************
	// * 		GUESTLIST CODE		 *
	// *******************************

	// Load guestlist page on navigation bar
	public function guestlist()
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->guestPosts();
		
		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('guestPosts', $viewData);
		$this->load->view('navBarGuest');
	}
	
	// Load all Posts on Posts button click
	public function allPosts()
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->guestPosts();
		
		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('guestPosts', $viewData);
		$this->load->view('navBarGuest');
	}

	public function postInfo($postID)
	{
		$this->load->model('UserMod');
		
		$data = $this->UserMod->postInfo($postID);

		$viewData['results'] = $data;

		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('guestPostsInfo', $viewData);
		$this->load->view('navBarGuest');
	}
	
	public function postLikes($postID)
	{
		$this->load->model('UserMod');
		
		$this->UserMod->postLikes($postID);
		
		$data = $this->UserMod->postInfo($postID);

		$viewData['results'] = $data;

		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('guestPostsInfo', $viewData);
		$this->load->view('navBarGuest');
		
		

	}
	
	
	public function socInfo($societyName)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->societyInfo($societyName);
		
		$viewData = array("results" => $data);
		
		$this->load->view('discoverHeader');
		$this->load->view('guestSocietyInfo', $viewData);
		$this->load->view('navBarDiscover');
	}
	
	public function joinSoc($societyID, $name)
	{
		$this->load->model('UserMod');
		
		
		if($this->UserMod->joinSoc($societyID, $name)){
			$this->allSocieties();
		}
		$this->allSocieties();
		
		
		//$viewData = array("results" => $data);
		
		//$this->load->view('guestHeader');
		//$this->load->view('guestSocietyInfo', $viewData);
		//$this->load->view('navBarGuest');
	}

	public function schoolInfo($school)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->schoolInfo($school);
		
		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('guestSchoolInfo', $viewData);
		$this->load->view('navBarGuest');
	}

	public function guestEventInfo($eventName)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->eventInfo($eventName);
		
		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('guestEventInfo', $viewData);
		$this->load->view('navBarGuest');
	}
	
	public function eventInfo($eventName)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->eventInfo($eventName);
		
		$viewData = array("results" => $data);
		
		$this->load->view('discoverHeader');
		$this->load->view('discoverEventInfo', $viewData);
		$this->load->view('navBarDiscover');
	}
	
	public function profileEventInfo($eventName)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->eventInfo($eventName);
		
		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('profileEventInfo', $viewData);
		$this->load->view('navBarGuest');
	}

	public function guestProfile($username)
	{
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profileHeader($username);
		
		$data2 = $this->UserMod->countEvent($username);
		
		$data3 = $this->UserMod->countPost($username);
		
		
		//$viewData = array("results" => $data);
		
		$viewData['results'] = $data;
		$viewData['results2'] = $data2;
		$viewData['results3'] = $data3;
		
		$this->load->view('guestProfileHeader', $viewData);
		
		
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profilePost($username);
		
		$viewData = array("results" => $data);
		
		if ($data == null) {
			
		$this->load->view('profileNoPosts');
		$this->load->view('navBarProfile');
		
		}
		else{
			
			$this->load->view('profilePosts', $viewData);
			$this->load->view('navBarProfile');
			
		}
	}

	// Load users Posts on Posts button click
	public function guestUserPosts($username)
	{
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profileHeader($username);
		
		$data2 = $this->UserMod->countEvent($username);
		
		$data3 = $this->UserMod->countPost($username);
		
		
		//$viewData = array("results" => $data);
		
		$viewData['results'] = $data;
		$viewData['results2'] = $data2;
		$viewData['results3'] = $data3;
		
		$this->load->view('guestProfileHeader', $viewData);
		
		$this->load->model('UserMod');
		$data = $this->UserMod->profilePost($username);
		$viewData = array("results" => $data);
		
		if ($data == null) {
			
		$this->load->view('profileNoPosts');
		$this->load->view('navBarProfile');
		
		}
		else{
			
			$this->load->view('profilePosts', $viewData);
			$this->load->view('navBarProfile');
			
		}
	}

	// Load users Events on Posts button click
	public function guestUserEvents($username)
	{
		$this->load->model('UserMod');
		
		$data = $this->UserMod->profileHeader($username);
		
		$data2 = $this->UserMod->countEvent($username);
		
		$data3 = $this->UserMod->countPost($username);
		
		
		//$viewData = array("results" => $data);
		
		$viewData['results'] = $data;
		$viewData['results2'] = $data2;
		$viewData['results3'] = $data3;
		
		$this->load->view('guestProfileHeader', $viewData);
		
		$this->load->model('UserMod');
		$data = $this->UserMod->profileEvent($username);
		$viewData = array("results" => $data);
		
		if ($data == null) {
			
		$this->load->view('profileNoEvents');
		$this->load->view('navBarProfile');
		
		}
		else{
			
			$this->load->view('profileEvents', $viewData);
			$this->load->view('navBarProfile');
			
		}
	}
	
	public function featuredEventInfo($eventName)
	{
		$this->load->model('UserMod');
		$data = $this->UserMod->eventInfo($eventName);
		
		$viewData = array("results" => $data);
		
		$this->load->view('guestHeader');
		$this->load->view('discoverEventInfo', $viewData);
		$this->load->view('navBarGuest');
	}
	
	
	
	
	
	
	//DO WE STILL NEED THIS OR CAN IT BE DELETED??
		
	//public function follow($followed)
	//{
	//	$this->load->model('UserMod');	
		
	//	$data = $this->UserMod->follow($followed);
		
	//	$this->load->helper('url');
			
	//	redirect(base_url()."index.php/user/view/".$followed);
	//}
	
	//public function feed($name = null)
	//{
	//	if($name==null)
	//	{
	//		echo "Username for feed not specified"; return; 
	//	}
		
	//	$this->load->model('MsgMod');
	//	$_SESSION["newsession2"]=($name);
	//	$data = $this->MsgMod->getFollowedMessages($name);
	//	$viewData = array("results" => $data);
	//	$this->load->view('msg_message - feed', $viewData);
	//}
	
}
?>