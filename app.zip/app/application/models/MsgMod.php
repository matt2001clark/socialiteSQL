<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MsgMod extends CI_Model  { 

	public function __construct()  {
	
		$this->load->database(); 
	}
	
	public function getMessages($username) {
		
		$sql = 'SELECT user_username, text, posted_at FROM Messages WHERE user_username = ? ORDER BY posted_at DESC';
		$query = $this->db->query($sql, array($username));
		return $query->result_array();

	}
	public function getSearch($textM) {
		
		$sql = 'SELECT user_username, text, posted_at FROM Messages WHERE text LIKE "%" ? "%" ORDER BY posted_at DESC';
		$query = $this->db->query($sql, array($textM));
		return $query->result_array();
		
	}
	public function insertMessage($poster, $string) {
		
		$postedAt = '. date("Y/m/d") ." ". date("h:i:s")'; 
		//tried adding date and time to new messages but kept coming back as (at 0000-00-00 00:00:00 ). 
		//This means any new messages are posted at the bottom of view messages.
		$sql = 'INSERT INTO Messages(user_username, text, posted_at) VALUES (?, ?, ?)';
		$query = $this->db->query($sql, array($poster, $string, $postedAt));
		
		
	}
	public function getFollowedMessages($name) {
		
		$sql = 'SELECT user_username, text, posted_at FROM User_Follows, Messages WHERE follower_username = ? AND followed_username = user_username';
		$query = $this->db->query($sql, array($name));
		return $query->result_array();
		
	}
}
?>