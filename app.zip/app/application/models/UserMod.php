<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserMod extends CI_Model  { 

	public function __construct()  {
	
		$this->load->database(); 
	}
	
	// *******************************
	// * 		LOGIN CODE		 	 *
	// *******************************

	public function checkLogin($username,$password) {
		$user = $username;
		$this->db->where('username',$username);
		$this->db->where('password',$password);
		$query = $this->db->get('Members');
		// $query = $this->db->get('Reps');
		
		if($query->num_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	// *******************************
	// * 		SIGNUP CODE		 	 *
	// *******************************

	 public function insertMember($Firstname, $Surname, $Username, $Password, $Bio, $School, $RepStatus){		
		
		$stm1 = 'SELECT StudentID 
				FROM Members 
				WHERE Username = ? 
				GROUP BY StudentID';
		$query1 = $this->db->query($stm1, array($Username));
		$StudentID = $query1->result_array();
		
		if ($StudentID == null){
		
	 	if($Firstname==null || $Surname==null || $Username==null || $Password==null || $Bio==null || ($Firstname==null && $Surname==null && $Username==null && $Password==null && $Bio==null && $School==null))
	 	{
	 		return false;
	 	}
		else if($RepStatus == null){
			$RepStatus = 0;
			$sql = 'INSERT INTO Members(StudentID, Firstname, Surname, Username, Password, Bio, School, RepStatus) 
					VALUES (?, ?, ?, ?, ?, ?, ?, ?);';
		
	 		$query = $this->db->query($sql, array(0, $Firstname, $Surname, $Username, $Password, $Bio, $School, $RepStatus));
		}
	 	else{
			$RepStatus = 1;
			
	 		$sql = 'INSERT INTO Members(StudentID, Firstname, Surname, Username, Password, Bio, School, RepStatus) 
					VALUES (?, ?, ?, ?, ?, ?, ?, ?);';
		
	 		$query = $this->db->query($sql, array(0, $Firstname, $Surname, $Username, $Password, $Bio, $School, $RepStatus));
	 	}
	 }
	 else{
		 return false;
	 }
	}


	// *******************************
	// * 		GUESTLIST CODE		 *
	// *******************************

	//display all posts from all members
	public function guestPosts() {
		$sql = 'SELECT p.Firstname, p.Content, p.PostID, p.Likes, m.School, e.EventName, e.EventID, m.Username
				FROM Posts p, Members m, Events e 
				WHERE p.EventID = e.EventID AND p.MembersID = m.StudentID
				ORDER BY PostID DESC;';
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	public function postInfo($postID) {
		
		$sql2 = 'SELECT p.Firstname, p.Content, p.PostID, p.Likes, m.School, e.EventName, e.EventID, e.Details, m.Username, s.SocietyName, s.SocietyID
				FROM Posts p, Members m, Events e, Societies s 
				WHERE p.PostID = ? AND p.EventID = e.EventID AND p.MembersID = m.StudentID AND e.SocietyID = s.SocietyID;';

		$query2 = $this->db->query($sql2, array($postID));
		return $query2->result_array();
	}
	
	public function postLikes($postID) {
		$sql = 'SELECT Likes 
				FROM Posts
				WHERE PostID = ?
				GROUP BY Likes';
		$query = $this->db->query($sql, array($postID));
		$currentLikes = $query->result_array()[0];
		
		
		
		$sql1 = 'UPDATE Posts SET Likes = ? + 1 WHERE PostID = ?;';
	
		$query2 = $this->db->query($sql1, array($currentLikes, $postID));
	}
	

	// public function postCountInfo($postID) {
	// 	$sql = 'SELECT COUNT(e.EventID), p.EventID
	// 			FROM Events e, Posts p
	// 			WHERE p.PostID = ? AND e.EventID = p.EventID;';
	// 	$query = $this->db->query($sql, array($postID));
	// 	return $query->result_array();
	// }

	public function schoolInfo($school) {
		$sql = 'SELECT DISTINCT m.School, m.Username, p.Content, p.Likes, p.PostID
				FROM Posts p, Members m
				WHERE m.School = ? AND p.MembersID = m.StudentID;';
		$query = $this->db->query($sql, array($school));
		return $query->result_array();
	}

	public function eventInfo($eventName) {
	
		$sql = 'SELECT e.EventName, e.Details, e.DateTime, v.VenueName, s.SocietyName, e.EventID 
				From Events e, Venues v, Societies s 
				WHERE e.EventID = ? AND e.VenueID = v.VenueID AND e.SocietyID = s.SocietyID;';
		$query = $this->db->query($sql, array($eventName));
		return $query->result_array();

	}

	public function societyInfo($societyName) {
	
		$sql = 'SELECT s.SocietyID, s.SocietyName, s.Category, r.Firstname, r.Surname 
				FROM Societies s, Reps r 
				WHERE s.SocietyID = ? AND s.RepsID = r.StudentID;';
		$query = $this->db->query($sql, array($societyName));
		return $query->result_array();

	}

	public function joinSoc($societyID, $name) {
	
		$stm1 = 'SELECT StudentID 
				FROM Members 
				WHERE Username = ?
				GROUP BY StudentID';
		$query1 = $this->db->query($stm1, array($name));
		$StudentID = $query1->result_array()[0];
	
	
		$sql = 'INSERT INTO Mapping (MapID, MembersID, SocietiesID)
				VALUES (?, ?, ?);';
		$query = $this->db->query($sql, array(0, $StudentID, $societyID));

	}	

	// *******************************
	// * 		DISCOVER CODE		 *
	// *******************************

	// Search for term in Events
	public function searchText($text)
	{
		$sql = 'SELECT e.EventName, e.Details, v.VenueName, e.EventID, s.SocietyName 
				FROM Events e, Venues v, Societies s 
				WHERE e.VenueID = v.VenueID AND s.SocietyID = e.SocietyID AND (e.EventName LIKE "%" ? "%" OR e.Details = "%" ? "%" OR v.VenueName LIKE "%" ? "%" OR s.SocietyName LIKE "%" ? "%") 
				ORDER BY e.EventID DESC;';
		$query = $this->db->query($sql, array($text,$text,$text,$text));
		return $query->result_array();
	}

	public function randEvent()
	{
		$sql = 'SELECT e.EventName, e.Details, v.VenueName, e.EventID, s.SocietyName 
				FROM Events e, Venues v, Societies s 
				WHERE e.VenueID = v.VenueID AND e.SocietyID = s.SocietyID 
				ORDER BY RAND() LIMIT 2;';
		$query = $this->db->query($sql, array());
		return $query->result_array();
	}

	//display all events from all societies
	public function discoverEvents() {
	
		$sql = 'SELECT e.EventName, e.Details, e.DateTime, v.VenueName, s.SocietyName, e.EventID 
				From Events e, Venues v, Societies s 
				WHERE e.VenueID = v.VenueID AND e.SocietyID = s.SocietyID
				ORDER BY e.DateTime DESC;';
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	//display all societies
	public function discoverSocieties() {

		$sql = 'SELECT s.SocietyName, s.Category, r.Firstname, r.Surname, s.SocietyID 
				FROM Societies s, Reps r 
				WHERE s.RepsID = r.StudentID;';
		$query = $this->db->query($sql);
		return $query->result_array();

	}

	//display all societies
	public function discoverPeople() {

		$sql = 'SELECT m.FirstName, m.School, m.Username
				FROM Members m
				ORDER BY m.School ASC, m.FirstName ASC;';
		$query = $this->db->query($sql);
		return $query->result_array();

	}

	// *******************************
	// * 		CREATE CODE		 *
	// *******************************

	public function insertPost($postContent, $postEvent, $name){
		$stm2 = 'SELECT EventID 
				FROM Events 
				WHERE EventName = ? 
				GROUP BY EventID';
		$query2 = $this->db->query($stm2, array($postEvent));
		$eventID = $query2->result_array();
		
		$eventID1 = "";
		
		foreach ($eventID as $row) {
			$eventID1 = $row['EventID'];
		}
		
		$stm3 = 'SELECT Firstname 
				FROM Members 
				WHERE Username = ?
				GROUP BY Firstname';
		$query3 = $this->db->query($stm3, array($name));
		$Firstname = $query3->result_array()[0];
		
		$stm5 = 'SELECT StudentID 
				FROM Members 
				WHERE Username = ?
				GROUP BY StudentID';
		$query5 = $this->db->query($stm5, array($name));
		$studentID = $query5->result_array()[0];
		
		
		if($postContent==null || $eventID1==null || ($postContent==null && $eventID1==null))
		{
			return false;
		}
		else{
		
		$sql = 'INSERT INTO Posts(PostID, Content, MembersID, Firstname, EventID, Likes) 
				VALUES (?, ?, ?, ?, ?, 0)';
		
		$query4 = $this->db->query($sql, array(0, $postContent, $studentID, $Firstname ,$eventID1));
		}
	}

	//if user is a rep then grab their information
	public function checkStatus($username){
		$sql = 'SELECT * 
				FROM Reps 
				WHERE username = ?;';
		$query = $this->db->query($sql, array($username));
		return $query->result_array();
	}

	public function insertEvent($eventName, $eventDetail, $eventVenue, $eventDate, $eventSociety){
		$stm1 = 'SELECT VenueID 
				FROM Venues 
				WHERE VenueName = ? 
				GROUP BY VenueID';
		$query1 = $this->db->query($stm1, array($eventVenue));
		$venueID = $query1->result_array();
		
		$venueID1 = "";
		
		foreach ($venueID as $row) {
			$venueID1 = $row['VenueID'];
		}
		
		$stm2 = 'SELECT SocietyID 
				FROM Societies 
				WHERE SocietyName = ? 
				GROUP BY SocietyID';
		$query2 = $this->db->query($stm2, array($eventSociety));
		$societyID = $query2->result_array();

		$societyID1 = "";
		
		foreach ($societyID as $row) {
			$societyID1 = $row['SocietyID'];
		}
		
		if($eventName==null || $eventDetail==null || $eventDate==null || ($eventName==null && $eventDetail==null) || ($eventName==null && $eventDate==null)  || ($eventDetail==null && $eventDate==null))
		{
			return false;
		}
		else{
			$sql = 'INSERT INTO Events(EventID, EventName, Details, DateTime, VenueID, SocietyID) 
					VALUES (?, ?, ?, ?, ?, ?)';
			
			$query3 = $this->db->query($sql, array(0, $eventName, $eventDetail, $eventDate, $venueID1, $societyID1));
		}
	}

	//POPULATE EVENTS DROPDOWN
	public function createPopulate(){
		$sql = 'SELECT EventID, EventName 
				FROM Events;';
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	//POPULATE SOCIETIES DROPDOWN
	public function createEventPopulate(){
		$sql = 'SELECT SocietyID, SocietyName 
				FROM Societies;';
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	//POPULATE VENUES DROPDOWN
	public function createVenuePopulate(){
		$sql = 'SELECT VenueID, VenueName 
				FROM Venues;';
		$query = $this->db->query($sql);
		return $query->result_array();
	}

	// *******************************
	// * 		PROFILE CODE		 *
	// *******************************
	
	// Profile Header 
	public function profileHeader($username)
	{
		$sql = 'SELECT DISTINCT mem.School, mem.Bio, mem.Username p.Content, e.Details, e.DateTime, v.VenueName, COUNT(p.Content), COUNT(e.EventName) 
				FROM Mapping map, Members mem, Events e, Venues v, Posts p 
				WHERE map.MembersID = mem.StudentID AND mem.Username = ? AND e.SocietyID = map.SocietiesID AND 
				v.VenueID = e.VenueID AND mem.StudentID = p.MembersID 
				GROUP BY mem.School, mem.Bio, mem.Username p.Content, e.Details, e.DateTime, v.VenueName;';
		
		$sql1 = 'SELECT mem.School, mem.Bio, mem.Username 
				FROM Members mem 
				WHERE mem.Username = ? 
				GROUP BY mem.School, mem.Bio;';
		
		$sql2 = 'SELECT p.Content, COUNT(p.Content) 
				FROM Posts p, Members mem, Mapping map 
				WHERE map.MembersID = mem.StudentID AND mem.Username = ? AND mem.StudentID = p.MembersID 
				GROUP BY p.Content;';
		
		$sql3 = 'SELECT e.Details, e.DateTime, v.VenueName, COUNT(e.EventName) 
				FROM Events e, Venues v, Members mem, Mapping map 
				WHERE map.MembersID = mem.StudentID AND mem.Username = ? AND e.SocietyID = map.SocietiesID AND v.VenueID = e.VenueID 
				GROUP BY e.Details, e.DateTime, v.VenueName;';
		
		$query = $this->db->query($sql1, array($username));
		
		return $query->result_array();
		

	}

	// Profile Post
	public function profilePost($username)
	{
		$sql = 'SELECT p.Firstname, p.Content, p.PostID, p.Likes, m.School, e.EventName, e.EventID, m.Username
				FROM Posts p, Members m, Events e 
				WHERE m.Username = ? AND p.EventID = e.EventID AND p.MembersID = m.StudentID
				ORDER BY PostID DESC;';
		$query = $this->db->query($sql, array($username));
		return $query->result_array();


		// $sql = 'SELECT m.School, m.Bio, p.Content
		// 		FROM Members m, Posts p 
		// 		WHERE m.Username = ? AND m.StudentID = p.MembersID 
		// 		GROUP BY m.School, m.Bio, p.Content;';
		// $query = $this->db->query($sql, array($username));
		// return $query->result_array();
	}

	// Profile Events 
	public function profileEvent($username)
	{
		$sql = 'SELECT e.EventName, e.Details, e.DateTime, v.VenueName, e.EventID, s.SocietyName 
				FROM Mapping map, Members mem, Events e, Venues v, Societies s 
				WHERE map.MembersID = mem.StudentID AND mem.Username = ? AND e.SocietyID = map.SocietiesID AND v.VenueID = e.VenueID AND e.SocietyID = s.SocietyID;';
		$query = $this->db->query($sql, array($username));
		return $query->result_array();
	}

	// Profile Post Count 
	public function countPost($username)
	{
		
		$sql = 'SELECT COUNT(p.Content)
				FROM Members m, Posts p
				WHERE m.Username = ? AND m.StudentID = p.MembersID;';
		$query = $this->db->query($sql, array($username));
		return $query->result_array();
	}

	// Profile Event Count
	public function countEvent($username)
	{
		$sql = 'SELECT COUNT(e.EventName) 
				FROM Mapping map, Members mem, Events e, Venues v 
				WHERE map.MembersID = mem.StudentID AND mem.Username = ? AND e.SocietyID = map.SocietiesID AND v.VenueID = e.VenueID;';
		$query = $this->db->query($sql, array($username));
		return $query->result_array();
	}
		
	
		
		

		
	
	
	
	
	
	
	
	
	
	//Old code, just using for referencing for now
	
	
	//public function isFollowing($follower, $followed) {
		
		//$this->db->where('follower_username',$follower);
	//	$this->db->where('followed_username',$followed);
		//$query = $this->db->get('User_Follows');
		
	//	if($query->num_rows() > 0)
	//	{
	//		return true;
	//	}
	//	else
	//	{
	//		return false;
	//	}
		
	//}
	//public function follow($followed) {
		
	//	$name = $_SESSION["newsession"];
	//	$sql = 'INSERT INTO User_Follows(follower_username, followed_username) VALUES (?, ?)';
	//	$query = $this->db->query($sql, array($name, $followed));
		
	//}

}
?>