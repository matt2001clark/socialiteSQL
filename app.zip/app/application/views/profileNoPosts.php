<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Profile</title>

	<style type="text/css">

	#profileContent {
        padding: 25vh 0 0 0;
		background-color: #faf9f6;
		height: 49.7vh;
	}

	.profile{
        padding: 10vh 0 0 0;
        height: 100vh;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width: 80%;
    }

	</style>
</head>
<body>

<div id="profileContent">
	<div class="profile">
		<table class="con_center">
			<!-- This is profilePosts page to display only active users posts 
			from database. Develop profileEvents as well. Reference profile page
			when developing some features need to be copied to this page -->
			<td> Haven't made any posts yet? Try it in the Create tab!
			</br> </br>
			</td>
			
		</table>
	</div>
</div>

</body>
</html>