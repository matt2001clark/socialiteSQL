<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Discover</title>

	<style type="text/css">
	
	/* Discover Header Styling */

	#discoverHeader{
        position: fixed;
        top: 0;
        width: 100%;
		height: 8vh;
		background: #faf9f6;
	}

	.header{
        background: #faf9f6;
		height: 8vh;
		color: black;
        letter-spacing: 20px;
		text-align: center;
		line-height: 6vh;
		font-size: 35px;
		font-family: Arial;
		padding: 0px 0px 0px 8px;
	}

    table.discover_center {
        margin-left:auto; 
        margin-right:auto;
		border-bottom-style: solid;
        border-bottom-color: #a8a4a4;
    }
	
	#td1 {
        padding-right: 8px;
	}

	input[type=submit]{
        display: inline;
		background-color: #faf9f6;
		color: #5094a4;
		border: none;
        /* border: 1.3px solid #a8a4a4; */
        border-radius: 50px;
		width: 90px;
        padding: 4px;
		margin: 0;
		text-align: right;

		/* display: inline;
		letter-spacing: 1px;
		font-family: Arial;
		float: right;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		font-size: 12px;
        width: 90px;
		height: 23px;
        margin: 6px 0 0 0; */
    }

	input[type=text] {
		display: inline;
		background-color: #faf9f6;
		color: #545252;
		padding: 4px;
		border: none;
		/* border: 1.3px solid #a8a4a4; */
		border-radius: 50px;
		margin: 0;
		width: 200px;
	}

	</style>
</head>

<body>
<?php $name = $_SESSION["newsession"]; ?>

<div id="discoverHeader">
	<div class="header">
		<table class="discover_center">
            <tr>
				<form id="discover_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/results" >
					<td id="td1"><input type="text" name="text" placeholder="Search the Socialite Community"/></td>
					<td><input type="submit" value="Search"></td>
				</form>
            </tr>
        </table>
	</div>	
</div>

</body>
</html>