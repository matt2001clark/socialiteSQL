<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Guest List</title>

	<style type="text/css">
	
	/* Guest List Header Styling */

	#guestHeader{
        position: fixed;
        top: 0;
		width: 100vw;
		height: 7vh;
		background: #faf9f6;
	}

	.header{
        background: #faf9f6;
		height: 10vh;
		color: black;
        letter-spacing: 4px;
		text-align: center;
		line-height: 6vh;
		font-size: 15px;
		font-family: Arial;
		width: 100%;
		margin: 0 0 10px 0; 
	}

    table.center {
        margin-left:auto; 
        margin-right:auto;
    }

    td.socialiteLogo{
        font-weight: bold;
        letter-spacing: 3px;
        font-family: Garamond;
        font-size: 23px;
    }

	</style>
</head>

<body>
<div id="guestHeader">
	<div class="header">
		<table class="center">
            <tr>
                <td class="socialiteLogo"> socialite</td>
                <!-- <td id="buttons">
                    <form id="guest_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/allPosts">
                        <input type="submit" value="Posts"/>
                    </form>
                    <form id="guest_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/allEvents">
                        <input type="submit" value="Events"/>
                    </form>
                    <form id="guest_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/allSocieties">
                        <input type="submit" value="Societies"/>
                    </form>
					<hr class="solid" id="line">
                </td> -->
				
            </tr>
        </table>
		
	</div>	
	
</div>

</body>
</html>