<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Create</title>

	<style type="text/css">

	#createContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: auto;
	}

	.create{
        padding: 5vh 0 0 0;
        height: 90vh;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
		
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width:80%;
    }
	
	select {
		background-color: #faf9f6;
		/* padding: 2px; */
		border:none;
		/* border: 1.3px solid #a8a4a4; */
		border-radius: 6px;
		width: 120px;
		float:left;
		text-align: left;
		margin: 0px;
	}

	#post{
		display: inline;
		padding: 4px;
		float:right;
		letter-spacing: 1px;
		font-family: Arial;
		font-size: 12px;
		float: right;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		width: 90px;
		height: 23px;
	}

	#postContent{
		width: 320px;
		height: 300px;
		padding: 4px;
		/* border-top: 1px solid; */
		border: none;
		/* border: 1px solid #a8a4a4; */
		border-radius: 6px;
		float:center;
		font-family: Arial;
		background-color: #faf9f6;
		/* margin-top: 0px;
		padding-top: 0px; */
		color: black;
		vertical-align: top;
		font-size: 18px;
	}

	div.inline{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		margin: 0 0vh 0 0vh;
	}

	div.inlinee{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		font-weight: bold;
		text-transform: uppercase;
		font-size: 20px;
		margin: 1.8vh 0vh 0vh 0.5vh;
	}

	div.right{
		/* background-color: pink; */
		float: right; 
		text-align: left;
		display:inline-block;
		font-weight: bold;
		text-transform: uppercase;
		font-size: 20px;
		margin: 2vh 2vh 0 0vh;
	}

	div.drop{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		/* font-weight: bold; */
		text-transform: uppercase;
		font-size: 10px;
		margin: 2vh 0vh 0 0vh;
	}

	.circle {
		height: 8.5vh; 	/*if too big in app make it 3vh 8.5*/
		width: 8.5vh;		/*if too big in app make it 3vh*/
		border-radius: 50%;
		margin: 2vh;
	}
		
	</style>
</head>
<body>
<?php $name = $_SESSION["newsession"]; ?>
<div id="createContent">
	<div class="create">
		<table class="con_center">
			<form id="create_post" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/addPost">
				<div class="inline">
					<p class="circle" style='background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>'></p>
				</div>
				<div class="inlinee">
					<?php echo $name; ?>
				</div>
				<div class="right">
					<input id="post" type="submit" value="Post"/>
				</div>
				<br></br>
				<div class="drop">
					<!-- <?php echo "School of Bio" ?> -->
					<select name="postEvent" id="event" method="POST">
			  		<?php foreach ($results as $row) {?>
						<option value="" disabled selected hidden>Select an event</option>
						<option value="<?php echo $row['EventName']; ?>"><?php echo $row['EventName']; ?></option>
			  		<?php } ?> 
				</select>
				</div>
				<br><br><br><br>
				<!-- IF IT DOESNT LOOK RIGHT ON THE PHONE UNCOMMENT THE BELOW BREAKS -->
				<!-- <br><br></br> -->
				<textarea id="postContent" type="text" name="postContent" placeholder="Socialite, what's on your mind?"></textarea>
			</form>
		</table>
	</div>
</div>

</body>
</html>		
			