<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Create</title>

	<style type="text/css">

	#signupContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: 70vh;
	}

	.signup{
        padding: 6vh 0 0 0;
        height: auto;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 10px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width:80%;
    }
	
	#eventDetail {
		width: 320px;
		height: 100px;
		padding: 6px;
		/* border: none; */
		border: 1px solid gray;
		border-radius: 10px;
		font-family: Arial;
		background-color: #faf9f6;
		flex-wrap: wrap;
		font-size: 18px;
	}

	#eventDetail::placeholder{
		color:black;
	}
	
	#firstName {
		width: 320px;
		font-size: 30px;
		border: none;
		background-color: #faf9f6;
		color:black;
		padding: 0px;
	}

	select{
		width: 336px;
		background-color: #faf9f6;
		color:black;
		border-radius: 10px;
		height:30px;
		font-size: 15px;
		border: 1px solid gray;
	}

	#eventDate {
		width: 333px;
		background-color: #faf9f6;
		color:black;
		border-radius: 10px;
		height:30px;
		font-size: 15px;
		border: 1px solid gray;
	}

	div.inline{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		margin: 0 0vh 0 10vh;
	}

	div.inlinee{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		font-weight: bold;
		text-transform: uppercase;
		font-size: 20px;
		margin: 2vh 0vh 0vh 0.5vh;
	}

	div.right{
		/* background-color: pink; */
		float: right; 
		text-align: left;
		display:inline-block;
		font-weight: bold;
		text-transform: uppercase;
		font-size: 20px;
		margin: 2vh 11vh 0 0vh;
	}

	div.drop{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		/* font-weight: bold; */
		/* text-transform: uppercase; */
		font-size: 12px;
		margin: 2vh 11vh 0 0.5vh;
		color: gray;
	}

	.circle {
		height: 8.5vh; 	/*if too big in app make it 3vh 8.5*/
		width: 8.5vh;		/*if too big in app make it 3vh*/
		border-radius: 50%;
		margin: 2vh;
	}

	#add{
		display: inline;
		padding: 4px;
		float:center;
		letter-spacing: 1px;
		font-family: Arial;
		font-size: 12px;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		width: 90px;
		height: 23px;
	}

	</style>
</head>
<body>

<div id="signupContent">
	<div class="signup">
		<table class="con_center">
			<form id="create_member" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/insertMember">
				
				<br/><br/>
				<input type="text" name="Firstname" placeholder="Enter First Name"/>
				<br/><br/>	<br/>
                    <input type="text" name="Surname" placeholder="Enter Last Name"/>
				<br/><br/><br/>
                    <input type="text" name="Username" placeholder="Enter Username" />
				<br/><br/><br/>
                    <input type="password" name="password" placeholder="Enter Password"/>
				<br/><br/><br/>
					<textarea type="text" name="Bio" placeholder="Tell the socialite community about yourself" ></textarea>
				<br/><br/> <br/>
				<select id="school" type="text" name="School" >
						<option value="" disabled selected hidden>Select school</option>
						<option value="Architecture">Architecture</option>
						<option value="Arts and Culture">Arts and Culture</option>
						<option value="Bioscience">Bioscience</option>
						<option value="Business">Business</option>
						<option value="Computing">Computing</option>
						<option value="Medicine">Medicine</option>
					</select>
				<br/><br/><br/>
				Are you a rep for a your society? <input id="repstatus" type="checkbox" name="RepStatus" value="1"/>
				<br/><br/><br/><br/>
				<input id="add" type="submit" value="Sign Up"/>
			</form>
			<br><br><br><br><br><br>
			<br><br><br><br>
		</table>
	</div>
</div>

</body>
</html>