<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Guest List</title>

	<style type="text/css">

	#guestContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: 70vh;
	}

	.guest{
        padding: 5vh 0 0 0;
        height: 200vh;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width: 80%;
    }
	
	#backButton {
		letter-spacing: 1px;
		font-family: Arial;
		font-size: 12px;
		float: right;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		margin: 1px 25px 0 0;
		width: 90px;
		height: 23px;
	}
	
	#joinButton {
		letter-spacing: 1px;
		font-family: Arial;
		font-size: 12px;
		float: left;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		margin: 1px 0 0 25px;
		width: 90px;
		height: 23px;
	}

	</style>
</head>
<body>
<?php $name = $_SESSION["newsession"]; ?>
<div id="guestContent">
	<div class="guest">
		<table class="con_center">
			<tr> 
			<?php foreach ($results as $row) {?>
					</br></br></br>
					Society Name: <?php echo $row['SocietyName']; ?> </br></br></br>
					Category: <?php echo $row['Category']; ?> </br></br></br>
					Rep's Name: <?php echo $row['Firstname']; ?>  <?php echo $row['Surname']; ?></br></br>
					
					<form id="back" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/view/<?php echo $name; ?>">
                        <input type="submit" id="backButton" value="< Discover"/>
                    </form>
					<form id="join" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/joinSoc/<?php echo $row['SocietyID']; ?>/<?php echo $name; ?>">
                        <input type="submit" id="joinButton" value="+ join"/>
                    </form>
				
			<?php } ?>
			</tr>
		</table>
	</div>
</div>

</body>
</html>