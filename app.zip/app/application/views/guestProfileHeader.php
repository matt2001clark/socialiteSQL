<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Profile</title>

	<style type="text/css">
	
	/* Profile Header Styling */

	#profileHeader{
        position: fixed;
        top: 0;
        width: 100%;
		height: 34vh;
        background: #faf9f6;
	}

    .header{
        background: #faf9f6;
		height: 34vh;
		color: black;
        letter-spacing: 2px;
		text-align: center;
		line-height: 6vh;
		font-size: 15px;
		font-family: Arial;
	}

    table.pro_center {
        margin-left:auto; 
        margin-right:auto;
        width: 90%;
        border-bottom-style: solid;
        border-bottom-color: #a8a4a4;

    }

    #username{
        /* font-weight: bold; */
        font-size: 13px;
        text-align: center;
    }

    #firstname{
        text-transform: uppercase;
        font-weight: bold;
        font-size: 18px;
        float: left;
    }

    #logout{
        float: right;
        padding-right: 8px;	
        color: #a8a4a4;
        font-size: 11.8px;
        letter-spacing: 1px;
    }

    #school{
        font-size: 14px;
        color: #a8a4a4;
        float: left;
    }

    #bio{
        font-size: 14px;
        float: left;
    }


    input[type=submit]{
        display: inline;
		background-color: #faf9f6;
		color: #a8a4a4;
        border: none;
        padding: 4px;
        letter-spacing: 1px;
        font-size: 12.5px;
		
    }
	
    form{
        display: inline;
    }
	
	#profile_form1 {
		float:left;
	}
	
	#profile_form2 {
		float:right;
	}

    #backButton {
		letter-spacing: 1px;
		font-family: Arial;
		float: right;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		font-size: 12px;
        width: 90px;
		height: 23px;
        margin: 6px 0 0 0;
	}

	</style>
</head>

<body>
<?php $name = $_SESSION["newsession"]; ?>

<div id="profileHeader">
<div class="header">
    <table class="pro_center">  
        <tr>  
        <td id="username">
            <?php foreach ($results as $viewData) {?>
				<?php echo $viewData['Username']; ?>
			<?php break; } ?>
        </td>
        </tr>
        <tr>
            <td id="firstname">
                <?php foreach ($results as $viewData) {?>
                    <?php echo $viewData['Username']; ?>
                <?php break; } ?>
            </td>
            <td id="logout">
                <!-- <ul><li> -->
                    <form id="back" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestlist">
                        <input type="submit" id="backButton" value="< Guest List"/>
                    </form>
                <!-- </li></ul> -->
            </td>
        </tr>
        <tr>
            <td id="school">School of 
			<?php foreach ($results as $viewData) {?>
				<?php echo $viewData['School']; ?>
			<?php break; } ?>
			</td>
        </tr>
        <tr>
            <td id="bio"> 
			<?php foreach ($results as $viewData) {?>
				<?php echo $viewData['Bio']; ?>
			<?php break; } ?>
			</td>
			
			<td id="bio"> 
			<?php $event = 0; ?>
			<?php foreach ($results2 as $viewData) {?>
				<?php $event = $viewData['COUNT(e.EventName)']; ?>
			<?php break; } ?>
			
			<?php $post = 0; ?>
			<?php foreach ($results3 as $viewData) {?>
				<?php $post = $viewData['COUNT(p.Content)']; ?>
			<?php  } ?>
			
			</td>
			
        </tr>
        <tr>
            <td>
                <!-- The XXX values should be replaced with count value of total posts and events attended -->
                <form id="profile_form1" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestUserPosts/<?php foreach ($results as $viewData) { echo $viewData['Username']; } ?>">
                    <input id="postCount" type="submit" value="Posts: <?php echo $post; ?>"  />
                    
                </form>
                <form id="profile_form2" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestUserEvents/<?php foreach ($results as $viewData) { echo $viewData['Username']; } ?>">
                    <input id="events" type="submit" value="Events: <?php echo $event; ?>"/>
                
                </form>
            </td>
        </tr>
    </table>
</div>	
</div>

</body>
</html>