<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Create</title>

	<style type="text/css">
	
	/* Create Header Styling */

	#createHeader{
        position: fixed;
        top: 0;
        width: 100%;
		height: 8vh;
		background: #faf9f6;
	}

	.header{
        background: #faf9f6;
		height: 8vh;
		color: black;
        letter-spacing: 20px;
		text-align: center;
		line-height: 6vh;
		font-size: 35px;
		font-family: Arial;
	}

    table.create_center {
        margin-left:auto; 
        margin-right:auto;
		border-bottom-style: solid;
        border-bottom-color: #a8a4a4;
    }

    input[type=submit]{
        display: inline;
		background-color: #faf9f6;
        border: none;
        /* border: 1.3px solid #a8a4a4; */
        border-radius: 6px;
		width: 130px;
        padding: 4px;
		color: #a8a4a4;
        letter-spacing: 1px;
        font-size: 12.5px;
    }

    form{
        display:inline;
		padding: 0px 13px 0px 0px;
    }

	</style>
</head>

<body>
<div id="createHeader">
	<div class="header">
		<table class="create_center">
            <tr>
                <td>
                    <form id="create_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/create">
                        <input type="submit" value="Create Post"/>
                    </form>
                    <form id="create_form" method ="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/createEvent">
                        <input type="submit" value="Create Event"/>
                    </form>
                </td>
            </tr>
        </table>
	</div>	
</div>

</body>
</html>