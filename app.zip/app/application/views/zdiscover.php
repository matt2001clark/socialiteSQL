<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CO600 Group Project - Discover</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #f9f9f9;
		margin: 0 5px 0 5px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
		height: 90vh;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: black;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 25px;
		font-family: 'Mochiy Pop P One', sans-serif;
		margin: 0 0 14px 0;
		padding: 20px 15px 20px 15px;
		text-align: center;
		
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}


	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
		background-color: lightblue;
		height: 80vh;
		text-align: left;
	}
	
	#h2 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 15px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 15px 15px 30px 15px;
		text-align: center;
	}
	
	#p1 {
		font-size: 15px;
		padding: 15px 15px 30px 15px;
	}
	
	#button{
		width:100%;
		text-align: center;
	}
	
	#button1{
		width:100%;
		text-align: center;
	}
	
	.f8{
		display: inline-block;
	}
	
	#f8{
		 float:left;
		 padding: 90px 15px 30px 15px;
	}
	
	#discover{
		background-image: url(
		'http://raptor.kent.ac.uk/proj/comp6000/project/46/discover.png');
		background-size: cover;
            width: 70px;
            height: 70px;
			font-weight: bold;
			text-align: bottom;	
			border-radius: 6px;
	}
	
	#create{
		background-image: url(
		'http://raptor.kent.ac.uk/proj/comp6000/project/46/create.png');
		background-size: cover;
            width: 70px;
            height: 70px;
			font-weight: bold;
			text-align: bottom;	
			border-radius: 6px;
	}
	
	#profile{
		background-image: url(
		'http://raptor.kent.ac.uk/proj/comp6000/project/46/profile.png');
		background-size: cover;
            width: 70px;
            height: 70px;
			font-weight: bold;
			text-align: bottom;	
			border-radius: 6px;
	}
	
	#guestlist{
		background-image: url(
		'http://raptor.kent.ac.uk/proj/comp6000/project/46/guestlist.png');
		background-size: cover;
            width: 70px;
            height: 70px;
			font-weight: bold;
			text-align: bottom;	
			border-radius: 6px;
	}
	
	
	
	</style>
</head>
<body>

<div id="container">
	<h1 id ="h1">Discover</h1>

	<div id="body">
	
	<h2 id="h2">
	
	
	<div id="button1">
	
	
	<form class = "f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/searchDates " >
	 <input type="submit" value="dates"/>
	</form>	
	
	<form class = "f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/searchCategory" >
	 <input type="submit" value="categories"/>
	</form>	
	
	</div>
	
	</h2>
	
	
	
	</div>
	<?php $name = $_SESSION["newsession"]; ?>
	
	<div id="button">
	
	<form class = "f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/view/<?php echo $name; ?> " >
	 <input type="submit" value="guest list" id="guestlist"/>
	</form>	
	
	<form class = "f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/view/<?php echo $name; ?> " >
	 <input type="submit" value="discover" id="discover"/>
	</form>	
	
	<form class = "f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/addEvent" >
	 <input type="submit" value="create" id="create"/>
	</form>
	
	<form class = "f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/profile" >
	 <input type="submit" value="profile" id="profile"/>
	</form>	
	
	</div>
	


	</div>
	
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>

</body>
</html>