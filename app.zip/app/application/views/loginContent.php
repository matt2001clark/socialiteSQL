<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Login</title>

	<style type="text/css">

	#loginContent {
		margin: 0 5px 0 5px;
		border: none;
		background-color: #faf9f6;
		height: 51vh;
		text-align: center;
	}

	.body {
		background-color: #faf9f6;
		height: 51vh;
		zoom: 120%;
	}
	
	#login_form {
		padding: 30px 15px 20px 15px;		
	}

	input{
		width: 55%;
		border: 1.5px solid #E0E0E0;
		border-radius: 3px;
		font-family: Arial;
		font-size: 12px;
		color: black;
		padding: 4px;
		background-color: #F0F0F0;
		margin: 1px, 10px;
	}
	
	input[type=submit]{
		background-color: #5094a4;
		color: white;
		border: 1.5px solid #5094a4;
		margin: 10px;
		width: 56%;   /** Only matches and aligns if 1% larger CHECK */
	}

	.head{
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background: #faf9f6;
		font-size: 35px;
		font-weight: bold;
		font-family: Garamond;
	}
	</style>
</head>
<body>

<div id="loginContent">
	<div class="head">
		socialite
	</div>
	<div class="body">
		<form id = "login_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/dologin" >
			<input type="text" name="username" placeholder="Username"/><br/><br/>
			<input type="text" name="password" placeholder="Password" id="myInput"/><br/><br/>
			<input type="submit" value="Log In"/>
		</form>	
	</div>
</div>

<script>

window.onload = myFunction;

function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

</body>
</html>