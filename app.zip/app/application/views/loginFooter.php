<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Login</title>

	<style type="text/css">

	#loginFooter {
		position: fixed;
        bottom:5px;
        width: 100%;
		height: 4vh;
		background: pink;
	}	

	.footer {
		position: fixed;
        bottom:5px;
        width: 100%;
		height: 4vh;
		text-align: center;
		font-family: Arial;
		font-size: 11px;
		line-height: 65px;
		padding: 0px 40px 20px 0px;
		background: #faf9f6;
	}

	a{
		color: #5094a4;
		text-decoration: none;
	}
	
	</style>
</head>
<body>
<div id="loginFooter">
	<div class="footer">
		Or Join The Socialite Community And 
		<a href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/signup">Sign Up</a>
	</div>
</div>
</body>

</html>