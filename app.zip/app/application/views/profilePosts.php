<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Profile</title>

	<style type="text/css">

	#profileContent {
        padding: 25vh 0 0 0;
		background-color: #faf9f6;
		height: auto;
	}

	.profile{
        padding: 10vh 0.1vh 0 3vh;
        height: auto;
		color: black;
		text-align: left;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:5px; 
        margin-right:20px;
		width: 90%;
    }

	#line {
        width: 60%;
    }

	.circle {
		height: 8.5vh; 	/*if too big in app make it 3vh 8.5*/
		width: 8.5vh;		/*if too big in app make it 3vh*/
		border-radius: 50%;
		/* margin: 2vh; */
		margin: 2.5vh 0 2vh 0vh;
	}

	div.inline{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
		padding: 0 0vh 0 0vh;
	}

	div.inlinee{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
	}

	div.content{
		text-align: left;
		padding: 0 0vh 0 0vh;
	}

	div.right{
		text-align: left;
		padding: 0 0vh 0 2vh;
		font-size: 10px;
		color: #5094a4;
		font-size: 12px;
	}

	hr{
		display: block;
		margin-top: 0;
		margin-bottom: 0;
		margin-left: auto;
		margin-right: auto;
		border-style: inset;
		border-width: 1px;
		border-color: white;
		background-color: white;
	}

	button.viewPost{
		border: none;
		width:100%;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
		color: black;
		/* margin: 0 5vh 0 5vh;
		text-align: left; */
	}

	button.viewUser{
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
		color: black;
		text-align:left;
		float:left;
		text-transform: uppercase;
		font-weight: bold;
		margin: 1vh 0vh 0vh 2vh;
	}

	button.viewEvent{
		text-align: left;
		/* font-weight: bold; */
		/* padding: 0 9vh 0 9vh; */
		font-size: 15px;
		color: #5094a4;
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-family: Arial;
		float: left;
		margin: 0vh 0vh 0vh 0vh;
	}
	</style>
</head>
<body>

<div id="profileContent">
	<div class="profile">
		<table class="con_center">
			<!-- This is profilePosts page to display only active users posts 
			from database. Develop profileEvents as well. Reference profile page
			when developing some features need to be copied to this page -->
			<?php foreach ($results as $row){?>
				<div class="inline">
				<p class="circle" style='background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>'></p>
				</div>
				<br>
				<form id=viewUser method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestProfile/<?php echo $row['Username']; ?>">
				<button class="viewUser" type="submit" value="">
				<div class="inlinee">
					<div>
						<?php echo $row['Firstname']; ?>
					</div>
				</button>
				</form>
				<br></br>
				<form id=viewEvent method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/eventInfo/<?php echo $row['EventID']; ?>">
				<button class="viewEvent" type="submit" value="">
					<div class="right">
						<?php echo $row['EventName']; ?>
					</div>	
				</button>
				</form>
				</div>
				<div>
				<form id=viewPost method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/postInfo/<?php echo $row['PostID']; ?>">
				<button class="viewPost" type="submit" value="">
					<div class=content>
						<?php echo $row['Content']; ?>
					</div>
					<br>
				</button>
				</form>
				<!-- <form id=viewEvent method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/eventInfo/<?php echo $row['EventID']; ?>">
				<button class="viewEvent" type="submit" value="">
					<div class="right">
						<?php echo $row['EventName']; ?>
					</div>	
				</button>
				</form> -->
				</div>
				<!-- <br></br> -->
				<hr>
			<?php } ?>






			<!-- <?php foreach ($results as $row) {?>
				<tr>
				<!-- <td>
					<p class="circle" style='background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>'></p> <br></br>
				</td> -->
				<!-- <td>				
				<br>
			 		<?php echo $row['Content']; ?>  <br></br>  <hr>
				</td>
				</tr> -->
			<!-- <?php } ?> --> 
		<br></br>
		</table>
		<br></br><br></br><br></br><br></br>
	</div>
</div>
	
</body>
</html>