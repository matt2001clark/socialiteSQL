<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Discover</title>

	<style type="text/css">

	#guestContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: 70vh;
	}

	.guest{
        padding: 5vh 0 0 0;
        height: auto;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width: 80%;
    }
	
	#button {
		width: 320px;
		height: 150px;
		padding: 4px;
		border: 1.3px solid #a8a4a4;
		border-radius: 6px;
		float:center;
		font-family: Arial;
		background-color: #faf9f6;
	}

    .rectangle {
		height: 10vh;
		width: 8.5vh;
		margin: 3vh 0 0 2vh;
	}

	div.inline{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
		padding: 0 0vh 0 0vh;
	}

	div.inlinee{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
	}

	div.right{
		text-align: left;
		padding: 0 8vh 0 2vh;
		font-size: 10px;
		color: #5094a4;
		font-size: 12px;
	}

    div.rightt{
		text-align: left;
		padding: 0vh 8vh 0 2vh;
		font-size: 10px;
		color: gray;
		font-size: 12px;
	}

	hr{
		display: block;
		margin-top: 0;
		margin-bottom: 0;
		margin-left: auto;
		margin-right: auto;
		border-style: inset;
		border-width: 1px;
		border-color: white;
		background-color: white;
	}

	button.viewUser{
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
		color: black;
		text-align:left;
		float:left;
		text-transform: uppercase;
		font-weight: bold;
		margin: 1.5vh 0vh 0vh 2vh;
	}

	button.viewEvent{
		text-align: left;
		/* font-weight: bold; */
		/* padding: 0 9vh 0 9vh; */
		font-size: 15px;
		color: #5094a4;
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-family: Arial;
		float: left;
		margin: 0vh 0vh 0vh 0vh;
	}

	</style>
</head>
<body>

<div id="guestContent">
	<div class="guest">
		<table class="con_center">
            <?php foreach ($results as $row){?>
				<div class="inline">
					<p class="rectangle" style='background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>'></p>
				</div>
					<br>
				<form id=create_form method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/socInfo/<?php echo $row['SocietyID']; ?>">
					<button class="viewUser" type="submit" value="">
					<div class="inlinee">
						<div>
							<?php echo $row['SocietyName']; ?>
						</div>
					</button>
				</form>
					<br>
				<form id=create_form method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/socInfo/<?php echo $row['SocietyID']; ?>">
					<button class="viewEvent" type="submit" value="">
						<div class="right">
							<?php echo "Rep: ",  $row['Firstname']; ?>
						</div>	
					</button>
				</form>
                <br></br>
                <form id=create_form method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/socInfo/<?php echo $row['SocietyID']; ?>">
					<button class="viewEvent" type="submit" value="">
						<div class="rightt">
							<?php echo  $row['Category']; ?>
						</div>	
					</button>
				</form>
					</div>
				<br></br><br>
				<!-- IF SPACING DOESN;T WORK IN APP UNCOMMENT BELOW -->
				<!-- </br><br></br> -->
				<hr>
			<?php } ?>
			
			</br> </br> </br> </br> </br> </br>
			<!-- <tr> 
			<?php foreach ($results as $row) {?>
				<form id="create_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/socInfo/<?php echo $row['SocietyID']; ?>">
					<p> </br> </br> <button type="submit" id="button">
					<?php echo $row['SocietyName']; ?>
					</button>
					</br> </br> </br> 
					<hr class="solid">
					</p>
				</form>	
			<?php } ?>
			</br> </br> </br> </br> </br> </br>
			
			</tr> -->
		</table>
	</div>
</div>

</body>
</html>