<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>CO600 Group Project - Your Events</title>

	<style type="text/css">
		::selection {
			background-color: #E13300;
			color: white;
		}

		::-moz-selection {
			background-color: #E13300;
			color: white;
		}

		body {
		background-color: #f9f9f9;
		margin: 0 5px 0 5px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
		height: 90vh;
		}

		a {
			color: #D0D0D0;
			background-color: transparent;
			font-weight: normal;

		}

		h1 {
			color: black;
			background-color: transparent;
			border-bottom: 1px solid #D0D0D0;
			font-size: 25px;
			font-family: 'Mochiy Pop P One', sans-serif;
			margin: 0 0 14px 0;
			padding: 20px 15px 20px 15px;
			text-align: center;

		}

		h2 {
			color: black;
			font-family: 'Mochiy Pop P One', sans-serif;

		}

		code {
			font-family: Consolas, Monaco, Courier New, Courier, monospace;
			font-size: 12px;
			background-color: #f9f9f9;
			border: 1px solid #D0D0D0;
			color: #002166;
			display: block;
			margin: 14px 0 14px 0;
			padding: 12px 10px 12px 10px;
		}

		#body {
			margin: 5px 15px 5px 15px;
		}

		p.footer {
			text-align: right;
			font-size: 11px;
			border-top: 1px solid #D0D0D0;
			line-height: 32px;
			padding: 0 10px 0 10px;
			margin: 20px 0 0 0;
		}

		#container {
			margin: 10px;
			border: 1px solid #D0D0D0;
			box-shadow: 0 0 8px #D0D0D0;
			background-color: lightblue;
			height: 80vh;
			text-align: left;
		}

		#h2 {
			color: black;
			background-color: transparent;
			border-bottom: 1px solid #D0D0D0;
			font-size: 15px;
			font-weight: normal;
			margin: 0 0 14px 0;
			padding: 15px 15px 30px 15px;
			text-align: Left;
		}

		#p1 {
			font-size: 15px;
		}

		#button1 {
			width: 100%;

			padding: 30px 0px 30px 0px;
		}

		#button1 {
			width: 100%;
			text-align: center;
		}
		
		#button2 {
			width:100%;
			text-align: center;

		}
		
		.f8{
		display: inline-block;
		}
		
		#f8{
			 float:left;
			 padding: 90px 15px 30px 15px;
		}
		
		#discover{
			background-image: url(
			'http://raptor.kent.ac.uk/proj/comp6000/project/46/discover.png');
			background-size: cover;
				width: 70px;
				height: 70px;
				font-weight: bold;
				text-align: bottom;	
				border-radius: 6px;
		}
		
		#create{
			background-image: url(
			'http://raptor.kent.ac.uk/proj/comp6000/project/46/create.png');
			background-size: cover;
				width: 70px;
				height: 70px;
				font-weight: bold;
				text-align: bottom;	
				border-radius: 6px;
		}
		
		#profile{
			background-image: url(
			'http://raptor.kent.ac.uk/proj/comp6000/project/46/profile.png');
			background-size: cover;
				width: 70px;
				height: 70px;
				font-weight: bold;
				text-align: bottom;	
				border-radius: 6px;
		}
		
		#guestlist{
			background-image: url(
			'http://raptor.kent.ac.uk/proj/comp6000/project/46/guestlist.png');
			background-size: cover;
				width: 70px;
				height: 70px;
				font-weight: bold;
				text-align: bottom;	
				border-radius: 6px;
		}
		
	</style>
</head>

<body>
	<div id="container">

		<?php $name = $_SESSION["newsession"]; ?>
		<div id="body">
			<h1 id="h1">Your Profile</h1>
			<h2 id="h2"><?php echo $name; ?></h2>
			<h2>School</h2> <!-- User school printed from the database-->
			<h2>Bio to be written here.</h2> <!-- The User bio printed from the database-->

			<!-- The button functions of the website-->

			<div id="button1">
				<!--Posts features-->
				<form class="f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/yourEvents">
					<!-- change this to echo directly here the next ? posts-->
					<input type="submit" <?php echo $name; ?> value="<?php echo $name; ?> Posts" />
					<!--Events features-->
					<form class="f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/yourEvents">
						<!-- change this to echo directly here the next ? events-->
						<input type="submit" <?php echo $name; ?> value="<?php echo $name; ?> Events" />
					</form>
					<!--Logout button-->
					<form class="f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/logout">
						<input type="submit" value="Logout" />
					</form>
			</div>

			<div id="button2">
				<!--Guess List-->
				<form class="f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/view/<?php echo $name; ?> ">
					<input type="submit" value="guest list" id="guestlist"/> <!-- this here to other ppl in the same society-->
				</form>
					<!--Discover-->
				<form class="f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/view/<?php echo $name; ?> ">
					<input type="submit" value="discover" id="discover"/> <!-- this will send the user to the calendar page-->
				</form>	
					<!--Create-->
				<form class="f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/addEvent">
					<input type="submit" value="create" id="create"/> <!-- this will send the user to the calendar page-->
					<!-- Profile-->
				</form>			
				<form class="f8" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/profile">
					<input type="submit" value="profile" id="profile"/> <!-- this will send the user to the profile page-->
				</form>
	
			</div>

		</div>




	</div>

	</div>

</body>

</html>