<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Login</title>

	<style type="text/css">
	
	/* Login Header Styling */

	#loginHeader{
		margin: 0 5px 0 5px;
		height: 30vh;
		background:#faf9f6;
	}
	</style>
</head>

<body>
<div id="loginHeader">
</div>

</body>
</html>