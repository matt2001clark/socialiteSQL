<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Create</title>

	<style type="text/css">

	#createContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: 70vh;
	}

	.create{
        padding: 5vh 0 0 0;
        height: 100vh;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 10px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width:80%;
    }
	
	#eventDetail {
		width: 320px;
		height: 100px;
		padding: 6px;
		/* border: none; */
		border: 1px solid gray;
		border-radius: 10px;
		font-family: Arial;
		background-color: #faf9f6;
		flex-wrap: wrap;
		font-size: 18px;
	}

	#eventDetail::placeholder{
		color:black;
	}
	
	#eventName {
		width: 320px;
		font-size: 30px;
		border: none;
		background-color: #faf9f6;
		color:black;
		padding: 0px;
	}

	select{
		width: 336px;
		background-color: #faf9f6;
		color:black;
		border-radius: 10px;
		height:30px;
		font-size: 15px;
		border: 1px solid gray;
	}

	#eventDate {
		width: 333px;
		background-color: #faf9f6;
		color:black;
		border-radius: 10px;
		height:30px;
		font-size: 15px;
		border: 1px solid gray;
	}

	div.inline{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		margin: 0vh 0vh 0 0vh;
	}

	div.inlinee{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		font-weight: bold;
		text-transform: uppercase;
		font-size: 20px;
		margin: 1.8vh 0vh 0vh 0vh;
	}

	div.right{
		/* background-color: pink; */
		float: right; 
		text-align: left;
		display:inline-block;
		font-weight: bold;
		text-transform: uppercase;
		font-size: 20px;
		margin: 2vh 2vh 0 0vh;
	}

	div.drop{
		/* background-color: pink; */
		float: left; 
		text-align: left;
		display:inline-block;
		/* font-weight: bold; */
		/* text-transform: uppercase; */
		font-size: 12px;
		margin: 2vh 11vh 0 0.5vh;
		color: gray;
	}

	.circle {
		height: 8.5vh; 	/*if too big in app make it 3vh 8.5*/
		width: 8.5vh;		/*if too big in app make it 3vh*/
		border-radius: 50%;
		margin: 2vh;
	}

	#add{
		display: inline;
		padding: 4px;
		float:right;
		letter-spacing: 1px;
		font-family: Arial;
		font-size: 12px;
		float: right;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		width: 90px;
		height: 23px;
	}

	</style>
</head>
<body>

<?php $name = $_SESSION["newsession"]; ?>
<div id="createContent">
	<div class="create">
		<table class="con_center">
			<form id="create_event" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/addEvent">
				<div class="inline">
					<p class="circle" style='background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>'></p>
				</div>
				<div class="inlinee">
					<?php echo $name; ?>
				</div>
				<div class="right">
					<input id="add" type="submit" value="Add"/>
				</div>
				<br></br><br>
				<div class="drop">
					<?php echo "President"; ?>
				</div>
				<br></br><br></br><br>
				<!-- IF IT DOESNT LOOK RIGHT ON THE PHONE UNCOMMENT THE BELOW BREAKS -->
				<!-- <br><br></br><br></br><br> -->
					<input id="eventName" type="text" name="eventName" placeholder="Name your event"/>
				<br/><br/>	
					<textarea id="eventDetail" type="text" name="eventDetail" placeholder="Enter a short description of your event"></textarea>
				<br/><br/> 
					<select id="eventVenue" type="text" name="eventVenue" method="POST">
						<?php foreach ($results as $row) {?>
							<option value="" disabled selected hidden>Select venue</option>
							<option value="<?php echo $row['VenueName']; ?>"><?php echo $row['VenueName']; ?></option>
						<?php } ?> 
					</select> 
				<br></br>
					<input id="eventDate" type="datetime-local" name="eventDate" placeholder="Select date"/>
				<br/><br/>	
					<select name="eventSociety" id="eventSociety" method="POST">
						<?php foreach ($results2 as $row) {?>
							<option value="" disabled selected hidden>Select society</option>
							<option value="<?php echo $row['SocietyName']; ?>"><?php echo $row['SocietyName']; ?></option>
						<?php } ?> 
					</select> 
			</form>
		</table>
	</div>
</div>

</body>
</html>