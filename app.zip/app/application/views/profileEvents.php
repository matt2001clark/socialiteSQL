<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Profile</title>

	<style type="text/css">

	#profileContent {
        padding: 25vh 0 0 0;
		background-color: #faf9f6;
		height: 90vh;
	}

	.profile{
        padding: 10vh 0.1vh 0 3vh;
        height: auto;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width: 80%;
    }
	
	#line {
        width: 60%;
    }
	
	#button {
		width: 320px;
		height: 150px;
		padding: 4px;
		border: 1.3px solid #a8a4a4;
		border-radius: 6px;
		float:center;
		font-family: Arial;
		background-color: #faf9f6;
		color: black;
	}

	.square {
		height: 8.5vh;
		width: 8.5vh;
		margin: 3vh 0 0 0vh;
	}

	div.inline{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
		padding: 0 0vh 0 0vh;
	}

	div.inlinee{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
	}

	div.right{
		text-align: left;
		padding: 1.2vh 0vh 0 2vh;
		font-size: 10px;
		color: #5094a4;
		font-size: 11.5px;
	}

	hr{
		display: block;
		margin-top: 0;
		margin-bottom: 0;
		margin-left: auto;
		margin-right: auto;
		border-style: inset;
		border-width: 1px;
		border-color: white;
		background-color: white;
	}

	button.viewUser{
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
		color: black;
		text-align:left;
		float:left;
		text-transform: uppercase;
		font-weight: bold;
		margin: 1vh 0vh 0vh 2vh;
	}

	button.viewEvent{
		text-align: left;
		/* font-weight: bold; */
		/* padding: 0 9vh 0 9vh; */
		font-size: 13px;
		color: #5094a4;
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-family: Arial;
		float: left;
		margin: 0vh 0vh 0vh 0vh;
	}

	</style>
</head>
<body>
<div id="profileContent">
	<div class="profile">
		<table class="con_center">
			<?php foreach ($results as $row){?>
				<div class="inline">
					<p class="square" style='background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>'></p>
				</div>
					<br>
				<form id=create_form method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/profileEventInfo/<?php echo $row['EventID']; ?>">
					<button class="viewUser" type="submit" value="">
					<div class="inlinee">
						<div>
							<?php echo $row['EventName']; ?>
						</div>
					</button>
				</form>
					<br></br>
				<form id=create_form method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/profileEventInfo/<?php echo $row['EventID']; ?>">
					<button class="viewEvent" type="submit" value="">
						<div class="right">
							<?php echo "Hosted by ",  $row['SocietyName']; ?>
						</div>	
					</button>
				</form>
					</div>
				<br></br><br>
				<!-- IF SPACING DOESN;T WORK IN APP UNCOMMENT BELOW -->
				<!-- </br><br></br> -->
				<hr>
			<?php } ?>
			</br> </br> </br> </br> </br> </br>
		</table>
	</div>
</div>

</body>
</html>