<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Guest List</title>

	<style type="text/css">

	#guestContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: 70vh;
	}

	.guest{
        padding: 5vh 0 0 0;
        height: auto;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width: 80%;
    }
	
	#button {
		width: 320px;
		height: 150px;
		padding: 4px;
		border: 1.3px solid #a8a4a4;
		border-radius: 6px;
		float:center;
		font-family: Arial;
		background-color: #faf9f6;
	}

	</style>
</head>
<body>

<div id="guestContent">
	<div class="guest">
		<table class="con_center">
			<tr> 
			<?php foreach ($results as $row) {?>
				<form id="create_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/socInfo/<?php echo $row['SocietyID']; ?>">
					<p> </br> </br> <button type="submit" id="button">
					<?php echo $row['SocietyName']; ?>
					</button>
					</br> </br> </br> 
					<hr class="solid">
					</p>
				</form>	
			<?php } ?>
			</br> </br> </br> </br> </br> </br>
			
			</tr>
		</table>
	</div>
</div>

</body>
</html>