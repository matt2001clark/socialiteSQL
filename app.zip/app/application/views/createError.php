<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Create</title>

	<style type="text/css">

	#createContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: 70vh;
	}

	.create{
        padding: 33vh 0 0 0;
        height: 70vh;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 10px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width:80%;
    }

	</style>
</head>
<body>

<div id="createContent">
	<div class="create">
		<table class="con_center">
			<tr><td style="font-size: 25px; font-weight: bold; color: #5094a4;">Reps Only!<td></tr>
			<tr><td> <!-- space --> <td></tr>
			<tr><td style="font-size: 13px; letter-spacing: 2px;">Sorry, you are unable to create an event.<td></tr>
			<tr><td> <!-- space --> <td></tr>
			<!-- <tr><td style="font-size: 8px; letter-spacing: 2px;">Become a rep!</td></tr> -->
		</table>
	</div>
</div>

</body>
</html>