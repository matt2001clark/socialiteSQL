<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite</title>

	<style type="text/css">

    #navBar {
		position: fixed;
        bottom:1.9em;
        width:100%;
		height: 12vh;
		background: #faf9f6;
	}

    .nav {
        bottom:4em;
        width:100%;
		text-align: center;
		font-family: Arial;
		font-size: 14px;
		background: #faf9f6;
        padding: 20px 0px 0px 0px;
		
	}

	a{color: #767373;
		text-decoration: none;
        padding: 10px 0px 0px 2px;
	}

    a.imglink{
        margin: 0;
        padding: 0;
    }

    img{
        height: 56px;
        width: 56px;
        padding: 0px 10px 0px 10px;
	}
	
    ul{
        list-style-type: none;
        margin: 0;
        padding: 0;
    }

    li{
        display: inline;
    }

    table.center {
        margin-left:auto; 
        margin-right:auto;
        margin-top: 0.4%;
        padding: 0px 0px 0px 0px;	
    }
	

	</style>
</head>
<body>

<?php $name = $_SESSION["newsession"]; ?>

<div id="navBar">
	<div class="nav">
        <table class="center">
            <tr>
                <td><a class="imglink" href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestlist"><img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/guestlist.png"></a></td>
                <td><a class="imglink" href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/view/<?php echo $name; ?>"><img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/discover.png"></a></td>
                <td><a class="imglink" href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/create"><img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/createBlue.png"></a></td>
                <td><a class="imglink" href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/profile/<?php echo $name; ?>"><img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/profile.png"></a></td>
            </tr>
            <tr>
                <td><ul><li><a href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestlist">Guest List</a></li></ul></td>
                <td><ul><li><a href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/view/<?php echo $name; ?>">Discover</a></li></ul></td>
                <td><ul><li><a style="color:#5094a4" href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/create">Create</a></li></ul></td>
                <td><ul><li><a href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/profile/<?php echo $name; ?>">Profile</a></li></ul></td>
            </tr>      
        </table>
	</div>
</div>

</body>
</html>