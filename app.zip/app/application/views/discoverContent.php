<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Discover</title>

	<style type="text/css">

	#discoverContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: auto;
	}

	.discover{
        height: auto;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width:80%;
    }
	
	#header {
		padding: 6vh 0 0 0;
	  	font-size: 30px;
	  	text-align: center;
		font-family: Arial;
	}
	
	#button {
		padding: 2vh;
		border: 4px solid #000000;
		border-radius: 3vh;
		float:center;
		/* position: absolute; */
		height:12vh;
		width:31vh; 
		/* border: none;  */
		font-size: 18px; 
		margin: 6px; 
		color: white;
	}

	/** Code from geek for geeks https://www.geeksforgeeks.org/programming-a-slideshow-with-html-and-css/ */
	
	#slideshow {
        overflow: hidden;
        height: auto;
        width: auto;
        margin: 0 auto;
    }
     
    /* Style each of the sides
    with a fixed width and height */
     
    .slide {
        float: left;
        height: 30vh;
        width: 50vh;
    }
     
    /* Add animation to the slides */
	.slide-wrapper {
         
		 /* Calculate the total width on the
	   basis of number of slides */
		 width: calc(50vh * 8);
		  
		 /* Specify the animation with the
	   duration and speed */
		 animation: slide 15s ease infinite;
	 }
	  
	 /* Set the background color
	 of each of the slides */
	  
	 .slide:nth-child(1) {
		 background: #d2afff;
	 }
	  
	 .slide:nth-child(2) {
		background: pink;
    }
     
    .slide:nth-child(3) {
        background: #800000;
    }
     
    .slide:nth-child(4) {
        background: yellow;
    }
	
	.slide:nth-child(5) {
		 background: #d2afff;
	 }
	  
	 .slide:nth-child(6) {
		background: pink;
    }
     
    .slide:nth-child(7) {
        background: #800000;
    }
     
    .slide:nth-child(8) {
        background: yellow;
    }
     
    /* Define the animation
    for the slideshow */
     
    @keyframes slide {
         
        /* Calculate the margin-left for
      each of the slides */
        20% {     
			margin-left: 0vh;
			/* margin-right: 3vh; */
        }
        40% {
            margin-left: calc(-50vh * 1);
        }
        60% {
            margin-left: calc(-50vh * 2);
        }
        80% {
            margin-left: calc(-50vh * 3);
        }
    }

	div.inline{
		display:inline-block;
		width: 80%;
	}

	div.featured{
		font-weight: bold;
		font-size: 18px;
		text-align: center;
		margin: 0 0 0 0px;
	}

	div.disTitle{
		font-weight: bold;
		font-size: 16px;
		text-align: left;
		margin: 0px 5px 0 0px;
	}

	div.disName{
		/* font-weight: bold; */
		font-size: 15px;
		text-align: left;
		margin: 0px 5px 0 0px;
	}

	hr{
		display: block;
		margin-top: 0;
		margin-bottom: 0;
		margin-left: auto;
		margin-right: auto;
		border-style: inset;
		border-width: 1px;
		border-color: white;
		background-color: white;
	}

	</style>
</head>
<body>

<div id="discoverContent">	
	<div class="discover">
	<br>
		<table class="con_center">
			<!-- Define the slideshow container -->
			<div id="slideshow">
			<div class="slide-wrapper">
				<!-- Define each of the slides
					and write the content -->
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img1.png" style="width:50vh; height:30vh">
				</div>
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img2.png" style="width:50vh; height:30vh">
				</div>
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img3.png" style="width:50vh; height:30vh">
				</div>
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img4.jpg" style="width:50vh; height:30vh">
				</div>
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img1.png" style="width:50vh; height:30vh">
				</div>
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img2.png" style="width:50vh; height:30vh">
				</div>
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img3.png" style="width:50vh; height:30vh">
				</div>
				<div class="slide">
					<img src="http://raptor.kent.ac.uk/proj/comp6000/project/46/img4.jpg" style="width:50vh; height:30vh">
				</div>
        	</div>
    		</div>
		</table>
		
		</br>
		
				<table class="con_center">
			<tr>
			<td>
				<div class="disTitle">
					<?php echo "Discover" ?>
				</div>
			</td>			
			<td>
				<div class="disName">
					<a href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/allPeople">People</a>
				</div>
			</td>
			<td>
				<div class="disName">
					<a href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/allEvents">Events</a>
				</div>
			</td>
			<td>
				<div class="disName">
					<a href="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/allSocieties">Societies</a>
				</div>
			</td>
			</tr>
		</table> 
		
		<br>
		<hr>
		<!-- <br> -->
		<table class="con_center">
			<div class="featured">
				<br>
				<?php echo "Featured Events" ?>
				<!-- <br></br> -->
			</div>
			<br>
		<?php foreach ($results as $row) {?>
			<form id="create_form" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/featuredEventInfo/<?php echo $row['EventID']; ?>">	
				<button type="submit" id="button" value="" style="background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>">	
					<div class="event">
						<?php echo "# " ,  $row['EventName']; ?>
					</div>
				</button>
			</form>
		<?php } ?>
		</br> </br> </br> </br> </br> </br></br> </br> </br> </br> </br> </br>
		</table>
	</div>
</div>

</body>
</html>