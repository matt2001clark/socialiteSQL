<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Socialite - Guest List</title>

	<style type="text/css">

	#guestContent {
		margin: 6vh 0 0 0;
		background-color: #faf9f6;
		height: 70vh;
	}

	.guest{
        padding: 5vh 0 0 0;
        height: 200vh;
		color: black;
		text-align: center;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
	}

    table.con_center {
        margin-left:auto; 
        margin-right:auto;
		width: 80%;
    }
	
	#backButton {
		letter-spacing: 1px;
		font-family: Arial;
		float: right;
		background-color: #5094a4;
		color: #ffffff;
		border: 1.3px solid #5094a4;
		border-radius: 50px;
		font-size: 12px;
        width: 90px;
		height: 23px;
        margin: 6px 0 0 0;
		paddding: 0 0 0 2vh;
	}

	.circle {
	height: 8.5vh; 	/*if too big in app make it 3vh 8.5*/
	width: 8.5vh;		/*if too big in app make it 3vh*/
	border-radius: 50%;
	margin: 2vh;
	}

	div.inline{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
		padding: 0 0 0 0vh;
	}

	div.inlinee{
		/* background-color: white; */
		float: left; 
		text-align: left;
		display:inline-block;
	}

	div.content{
		text-align: left;
		padding: 0 0vh 0 2vh;
	}

	div.right{
		text-align: right;
		padding: 0 2vh 0 2vh;
		font-size: 10px;
		color: #5094a4;
	}

	hr{
		display: block;
		margin-top: 0;
		margin-bottom: 0;
		margin-left: auto;
		margin-right: auto;
		border-style: inset;
		border-width: 1px;
		border-color: white;
		background-color: white;
	}

	button.viewPost{
		border: none;
		width:100%;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
		color: black;
		/* margin: 0 5vh 0 5vh;
		text-align: left; */
	}

	button.viewUser{
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 14px;
		font-family: Arial;
		color: black;
		text-align:left;
		float:left;
		text-transform: uppercase;
		font-weight: bold;
		margin: 1vh 0vh 0vh 0vh;
	}

	button.viewSchool{
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-size: 12px;
		font-family: Arial;
		color: gray;
		text-align:left;
		/* height: 3vh; */
		float: left;
		/* margin: 0vh 25vh 0vh 0vh; */
		/* margin: 5vh 0 0 0; */
	}

	button.viewEvent{
		text-align: right;
		/* padding: 0 9vh 0 9vh; */
		font-size: 10px;
		color: #5094a4;
		border: none;
		letter-spacing: 3px;
		background-color: #faf9f6;
		font-family: Arial;
		float: right;
		/* margin: 1vh 0vh 0vh 0vh; */
	}


	</style>
</head>
<body>

<div id="guestContent">
	<div class="guest">
		<table class="con_center">
            <tr>
            <form id="back" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestlist">
                <input type="submit" id="backButton" value="< Guest List"/>
            </form>
			<br></br>
			<?php foreach ($results as $row){?>
				<div class="inline">
					<p class="circle" style='background-color:<?php printf( "#%06X\n", mt_rand( 0, 0x222222 )); ?>'></p>
				</div>
					<br>
				<form id=create_form method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/guestProfile/<?php echo $row['Username']; ?>">
					<button class="viewUser" type="submit" value="">
					<div class="inlinee">
						<div>
							<?php echo $row['Username']; ?>
						</div>
					</button>
				</form>
					<br></br>
				<form id=viewSchool method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/schoolInfo/<?php echo $row['School']; ?>">
				<button class="viewSchool" type="submit" value="">
					<div>
						School of <?php echo $row['School']; ?>
					</div>
				</button>
				</form>
					</div>
					<div>
				<form id=viewPost method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/postInfo/<?php echo $row['PostID']; ?>">
				<button class="viewPost" type="submit" value="">
					<div class=content>
						<?php echo $row['Content']; ?>
					</div>
					<br>
				</button>
				</form>
				</div>
				<br>
				<!-- IF SPACING DOESN;T WORK IN APP UNCOMMENT BELOW -->
				<!-- </br><br></br> -->
				<hr>
			<?php } ?>

			</tr>
		</table>
	</div>
</div>

</body>
</html>