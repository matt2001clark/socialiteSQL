<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CO600 Group Project - Login Screen</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #f9f9f9;
		margin: 0 5px 0 5px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
		height: 90vh;
		zoom: 120%;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 40px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 20px 15px 20px 15px;
		text-align: center;
		font-family: "Lucida Console", "Courier New", monospace;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 5px 0 5px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
		background-color: lightblue;
		height: 80vh;
		text-align: center;
	}
	
	#p1 {
		font-size: 12px;
	}
	
	#p2 {
		font-size: 15px;
	}
	
	#my_form2 {
		padding: 80px 15px 20px 15px;
		
	
}
	#submit_button
	{
			background-color: #0000FF;
			padding: 0 50px 0 50px;
			border-radius: 8px;
			border: 2px solid #555555;
			color: white;
	}
	</style>
</head>
<body>

<div id="container">
	<h1 id ="h1">socialite</h1>

	<div id="body">
	
	<form id = "my_form2" method="POST" action="http://raptor.kent.ac.uk/proj/comp6000/project/46/app/index.php/user/dologin" >
	 <input type="text" name="username" placeholder="Username"/><br/><br/>
	 <input type="text" name="password" placeholder="Password" id="myInput" /><br/><br/>
	 <input type="submit" value="Log In" id="submit_button"/>
	</form>	
	
		
	
	</div>

	
</div>

<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>

<script>

window.onload = myFunction;

function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

</body>
</html>